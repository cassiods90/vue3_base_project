/// <reference types="@nuxtjs/color-mode" />
/// <reference types="@nuxt/telemetry" />
/// <reference types="@pinia/nuxt" />
/// <reference path="types/builder-env.d.ts" />
/// <reference path="types/plugins.d.ts" />
/// <reference path="types/build.d.ts" />
/// <reference path="types/app.config.d.ts" />
/// <reference path="types/runtime-config.d.ts" />
/// <reference types="nuxt/app" />
/// <reference types="C:/Users/cassi/OneDrive/Documentos/Meus Arquivos/My Projects/Vue/vue3_base_project/node_modules/@nuxt/nitro-server/dist/index.mjs" />
/// <reference types="@pinia/nuxt" />
/// <reference types="vue-router" />
/// <reference path="types/middleware.d.ts" />
/// <reference path="types/nitro-middleware.d.ts" />
/// <reference path="types/layouts.d.ts" />
/// <reference path="types/components.d.ts" />
/// <reference path="imports.d.ts" />
/// <reference path="types/imports.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />
/// <reference path="types/nitro.d.ts" />

export {}
