/// <reference types="@nuxtjs/color-mode" />
/// <reference types="@nuxt/telemetry" />
/// <reference types="@pinia/nuxt" />
/// <reference path="types/modules.d.ts" />
/// <reference path="types/runtime-config.d.ts" />
/// <reference path="types/app.config.d.ts" />
/// <reference types="nuxt" />
/// <reference types="../node_modules/@nuxt/vite-builder/dist/index.mjs" />
/// <reference types="C:/Users/cassi/OneDrive/Documentos/Meus Arquivos/My Projects/Vue/vue3_base_project/node_modules/@nuxt/nitro-server/dist/index.mjs" />
/// <reference path="types/nitro-middleware.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />

export {}
