<template>
    <div class="pages">
        <div class="page-title">
            <h1 class="text text-weightBold text-maintitle text-center">Carousel Test Import</h1>
        </div>
        <div class="page-content">
            <HomeSwiperCarouselExample />
        </div>
    </div>
</template>

<script setup></script>
