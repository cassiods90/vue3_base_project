<template>
    <div class="pages">
        <div class="page-title">
            <h1 class="text text-weightBold text-maintitle text-center">Nuxt 3 Home</h1>
        </div>
        <div class="page-content">
            <span class="text text-secondary text-center">
                Welcome to your Nuxt 4 base project! Use the navigation bar to explore different examples like Carousel and Pinia state management.
            </span>
        </div>
    </div>
</template>

<script setup></script>
