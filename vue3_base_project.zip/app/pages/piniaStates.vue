<template>
    <div class="pages">
        <div class="page-title">
            <h1 class="text text-weightBold text-maintitle text-center">Pinia for states</h1>
        </div>
        <div class="page-content">
            <HomePiniaExample />
        </div>
    </div>
</template>

<script setup></script>
