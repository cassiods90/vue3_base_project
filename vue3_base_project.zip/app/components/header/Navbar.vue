<template>
    <div class="header-navbar d-flex justify-content-center align-items-center">
        <nuxtLink class="navbar-item text" to="/"> Home </nuxtLink>
        <nuxtLink class="navbar-item text" to="/carouselTest"> Carousel Test </nuxtLink>
        <nuxtLink class="navbar-item text" to="/piniaStates"> Pinia States </nuxtLink>
    </div>
</template>

<script setup></script>
