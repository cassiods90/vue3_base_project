<template>
    <div class="d-flex justify-content-center align-items-center gap-2">
        <button class="btn-item" @click="counter.decrement">
            <span class="text">--</span>
        </button>

        <span class="text">Pinia Counter: {{ counter.count }}</span>

        <button class="btn-item" @click="counter.increment">
            <span class="text">++</span>
        </button>
    </div>
</template>

<script setup>
import { useCounter } from '@/stores/counter'

const counter = useCounter()
</script>
