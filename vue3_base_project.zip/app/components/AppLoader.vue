<template>
    <div class="loader-initial showHide">
        <div class="loader-content"></div>
    </div>
</template>

<script setup></script>
