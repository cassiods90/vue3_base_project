<template>
    <div class="footer d-flex justify-content-center align-items-center">
        <FooterCopyright />
    </div>
</template>

<script setup></script>
