<template>
    <div class="header d-flex justify-content-center align-items-center">
        <HeaderNavbar />
        <HeaderPageTheme />
    </div>
</template>

<script setup></script>
