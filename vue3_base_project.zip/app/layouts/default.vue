<template>
    <header>
        <AppHeader />
    </header>

    <main>
        <slot></slot>
    </main>

    <footer>
        <AppFooter />
    </footer>
</template>
